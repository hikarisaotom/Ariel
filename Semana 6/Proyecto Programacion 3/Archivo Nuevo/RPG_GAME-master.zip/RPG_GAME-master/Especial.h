#include "Ataque.h"
#include <iostream>
#include <string>

#ifndef ESPECIAL_H
#define ESPECIAL_H

class Especial:public Ataque{
	private:
	public:
		Especial();
		~Especial();
};

#endif
