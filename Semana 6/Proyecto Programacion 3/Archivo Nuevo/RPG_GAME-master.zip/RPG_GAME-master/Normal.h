#ifndef NORMAL_H
#define NORMAL_H
#include "Ataque.h"
class Normal : public Ataque{
	private:
	public:
		Normal();
};
#endif
