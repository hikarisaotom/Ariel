#include "Normal.h"

Normal:: Normal(){

}
