//Bienvenido
#include <string>
#include <iostream>
#include "Personaje.h"

using namespace std;

#ifndef ASSASSIN_H
#define ASSASSIN_H


//Inicio clase
class Assassin:public Personaje{

    //Atributos
    private:
       


    //metodos publicos
    public:
        //prototipos de metodos
        //constructor
        Assassin();
       

        //metodos accersores / mutadores
       
    //Destructor
    ~Assassin();


};//Fin de la clase


#endif