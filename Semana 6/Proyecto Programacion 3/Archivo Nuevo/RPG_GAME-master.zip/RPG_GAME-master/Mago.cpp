//Metodo sets ade gets

#include "Mago.h"
#include <iostream>
#include <string>

using namespace std;



//Constructor2
Mago::Mago(){

}//Fin constructor sencillo



Mago::~Mago(){

    cout<<"La instancia de Mago fue eliminada";

}