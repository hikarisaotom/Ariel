    #include "Assassin.h"
#include <iostream>
#include <string>

using namespace std;


//Constructor2
Assassin::Assassin(){

}//Fin constructor sencillo




Assassin::~Assassin(){

    cout<<"La instancia de Assassin fue eliminada";

}