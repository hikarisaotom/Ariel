#include "Mago.h"
#include "Assassin.h"
#include "Brute.h"
#include "Item.h"
#include "Normal.h"
#include "Personaje.h"
#include <iostream>
#include <string>

using namespace std;

int main()
{
	return 0;
}
