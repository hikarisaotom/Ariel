//Bienvenido
#include <string>
#include <iostream>
#include "Personaje.h"

using namespace std;

#ifndef BRUTE_H
#define BRUTE_H


//Inicio clase
class Brute:public Personaje{

    //Atributos
    private:
        

    //metodos publicos
    public:
        //prototipos de metodos
        //constructor
        Brute();
        

        //metodos accersores / mutadores
       

    //Destructor
    ~Brute();


};//Fin de la clase


#endif