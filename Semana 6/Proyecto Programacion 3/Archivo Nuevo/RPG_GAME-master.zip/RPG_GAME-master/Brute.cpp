//Metodo sets ade gets

#include "Brute.h"
#include <iostream>
#include <string>

using namespace std;



//Constructor2
Brute::Brute(){

}//Fin constructor sencillo



Brute::~Brute(){

    cout<<"La instancia de Brute fue eliminada";

}